package  com.neoh.calculadora;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText nr1;
    private EditText nr2;
    private EditText result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        nr1 = findViewById(R.id.nr1);
        nr2 = findViewById(R.id.nr2);
        result = findViewById(R.id.result);
    }

    public void adicao(View v) {
        if (!nr1.getText().toString().isEmpty() && !nr2.getText().toString().isEmpty()) {
            float p = Float.parseFloat(nr1.getText().toString());
            float a = Float.parseFloat(nr2.getText().toString());
            float res = p + a;
            result.setText(Float.toString(res));

            // Enviar dados para a classe GraphActivity
            Intent intent = new Intent(MainActivity.this, GraphActivity.class);
            intent.putExtra("Resultado", res);
            intent.putExtra("Valor1", p);
            intent.putExtra("Valor2", a);
            startActivity(intent);
        } else {
            result.setText("Algum dos campos não foi preenchido");
        }
    }

    public void subtracao(View v) {
        if (!nr1.getText().toString().isEmpty() && !nr2.getText().toString().isEmpty()) {
            float p = Float.parseFloat(nr1.getText().toString());
            float a = Float.parseFloat(nr2.getText().toString());
            float res = p - a;
            result.setText(Float.toString(res));

            // Enviar dados para a classe GraphActivity
            Intent intent = new Intent(MainActivity.this, GraphActivity.class);
            intent.putExtra("Resultado", res);
            intent.putExtra("Valor1", p);
            intent.putExtra("Valor2", a);
            startActivity(intent);
        } else {
            result.setText("Algum dos campos não foi preenchido");
        }
    }

    public void multiplicacao(View v) {
        if (!nr1.getText().toString().isEmpty() && !nr2.getText().toString().isEmpty()) {
            float p = Float.parseFloat(nr1.getText().toString());
            float a = Float.parseFloat(nr2.getText().toString());
            float res = p * a;
            result.setText(Float.toString(res));

            // Enviar dados para a classe GraphActivity
            Intent intent = new Intent(MainActivity.this, GraphActivity.class);
            intent.putExtra("Resultado", res);
            intent.putExtra("Valor1", p);
            intent.putExtra("Valor2", a);
            startActivity(intent);
        } else {
            result.setText("Algum dos campos não foi preenchido");
        }
    }

    public void divisao(View v) {
        if (!nr1.getText().toString().isEmpty() && !nr2.getText().toString().isEmpty()) {
            float p = Float.parseFloat(nr1.getText().toString());
            float a = Float.parseFloat(nr2.getText().toString());
            if (a != 0) {
                float res = p / a;
                result.setText(Float.toString(res));

                // Enviar dados para a classe GraphActivity
                Intent intent = new Intent(MainActivity.this, GraphActivity.class);
                intent.putExtra("Resultado", res);
                intent.putExtra("Valor1", p);
                intent.putExtra("Valor2", a);
                startActivity(intent);
            } else {
                result.setText("Divisão por zero não é permitida");
            }
        } else {
            result.setText("Algum dos campos não foi preenchido");
        }
    }
}
