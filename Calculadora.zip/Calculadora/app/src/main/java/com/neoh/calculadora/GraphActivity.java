package com.neoh.calculadora;

import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

public class GraphActivity extends AppCompatActivity {

    private GraphView graphView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_graph);

        graphView = findViewById(R.id.graphView);

        Bundle extras = getIntent().getExtras();
        if (extras != null && extras.containsKey("result")) {
            float result = extras.getFloat("result");
            float nr1 = extras.getFloat("nr1");
            float nr2 = extras.getFloat("nr2");

            //  criação de pontos de dados para o gráfico
            DataPoint[] dataPoints = new DataPoint[]{
                    new DataPoint(nr1, result),
                    new DataPoint(nr2, result)
            };

            // Criação da série de gráfico de linha com os pontos de dados
            LineGraphSeries<DataPoint> series = new LineGraphSeries<>(dataPoints);

            // Adiciona a série de gráfico ao GraphView
            graphView.addSeries(series);
        } else {
            Toast.makeText(this, "Dados inválidos", Toast.LENGTH_SHORT).show();
            finish();
        }
    }
}
